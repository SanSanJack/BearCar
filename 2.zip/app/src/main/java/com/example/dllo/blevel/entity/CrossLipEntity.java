package com.example.dllo.blevel.entity;

/**
 * Created by WYL on 2017/4/26.
 */

public class CrossLipEntity {
    public String getTitles() {
        return titles;
    }

    public void setTitles(String titles) {
        this.titles = titles;
    }

    public CrossLipEntity(String titles) {
        this.titles = titles;
    }

    private  String  titles;
}
