package com.example.dllo.blevel.entity;

import java.util.List;

/**
 * Created by dllo on 17/4/28.
 */

public class BrandsEntity {


    private int total;
    private List<Integer> idxes;
    private List<String> names;

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public List<Integer> getIdxes() {
        return idxes;
    }

    public void setIdxes(List<Integer> idxes) {
        this.idxes = idxes;
    }

    public List<String> getNames() {
        return names;
    }

    public void setNames(List<String> names) {
        this.names = names;
    }
}
