package com.example.dllo.blevel.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.dllo.blevel.R;
import com.example.dllo.blevel.entity.BearCarEntity;

import java.util.List;

/**
 * Created by WYL on 2017/4/25.
 */

public class DialogListViewAdapter extends BaseAdapter {
    //    private Context context;
    private List<BearCarEntity> carEntities;
    private LayoutInflater mInflater;

    public DialogListViewAdapter(Context context) {
//        this.context = context;
        mInflater = LayoutInflater.from(context);
        notifyDataSetChanged();
    }


    public void setDialogListViewAdapter(List<BearCarEntity> carEntities) {
        this.carEntities = carEntities;
        notifyDataSetChanged();
    }

    @Override

    public int getCount() {
        return carEntities.size();
    }

    @Override
    public Object getItem(int position) {
        return carEntities.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder = null;
        if (convertView == null) {
            Log.d("DialogListViewAdapter", "convertView:" + convertView);
            convertView = mInflater.inflate(R.layout.item_dialog_car, parent, false);
//            Log.d("DialogListViewAdapter", "context:" + context);

            holder = new ViewHolder(convertView);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }
//        if (position == 0) {
//            holder.tv.setText("我的小车");
//        }
        holder.tv.setText(carEntities.get(position).getName());
        return convertView;
    }

    class ViewHolder {
        TextView tv;

        private ViewHolder(View itemView) {
            tv = (TextView) itemView.findViewById(R.id.tv_listview_add);
        }
    }
}
