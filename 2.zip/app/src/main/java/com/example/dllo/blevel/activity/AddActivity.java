package com.example.dllo.blevel.activity;

import android.view.View;

import com.example.dllo.blevel.R;
import com.example.dllo.blevel.base.BaseActivity;

/**
 * Created by dllo on 17/4/28.
 */

public class AddActivity extends BaseActivity {
    @Override
    public int setLayout() {
        return R.layout.activity_update;
    }

    @Override
    public void initView() {

    }

    @Override
    protected void initData() {

    }

    @Override
    protected void setListener() {

    }

    @Override
    public void onClick(View v) {

    }
}
